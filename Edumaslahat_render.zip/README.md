# @EduMaslahat_bot — Render va GitHub uchun tayyor loyiha

## Render'da ishga tushirish
1. GitHub repository (Private) ichiga `bot.py`, `requirements.txt` va `README.md` fayllarini yuklang.
2. Render'da **Build Command**: `pip install -r requirements.txt`
3. Render'da **Start Command**: `python bot.py`
4. Render -> **Environment -> Environment Variables** bo'limiga:
   - `BOT_TOKEN` = `@BotFather` bergan token
   - `ADMIN_IDS` = Telegram ID raqamingiz
5. **Deploy** tugmasini bosing.
