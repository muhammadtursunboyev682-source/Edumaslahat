import asyncio
import logging
import os
import sqlite3
from datetime import datetime

from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
)

# ==========================================
# 1. SOZLAMALAR (CONFIG)
# ==========================================
# Tokenni Render -> Environment Variables bo'limiga BOT_TOKEN nomi bilan kiriting
# yoki shu yerdagi qo'shtirnoq ichiga yozing:
BOT_TOKEN = os.getenv("BOT_TOKEN", "BU_YERGA_BOTFATHER_TOKENINI_QOYING").strip()
ADMIN_IDS_RAW = os.getenv("ADMIN_IDS", "123456789")
ADMIN_IDS = [int(x.strip()) for x in ADMIN_IDS_RAW.split(",") if x.strip().isdigit()]

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_NAME = os.path.join(BASE_DIR, "edumaslahat.db")

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()


# ==========================================
# 2. MA'LUMOTLAR BAZASI (SQLITE)
# ==========================================
def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            full_name TEXT,
            username TEXT,
            role TEXT,
            created_at TEXT
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            full_name TEXT,
            question_text TEXT,
            answer_text TEXT,
            status TEXT DEFAULT 'open',
            created_at TEXT
        )
    """)
    conn.commit()
    conn.close()


def save_user(user_id: int, full_name: str, username: str, role: str = None):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT role FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    if row is None:
        cursor.execute(
            "INSERT INTO users (user_id, full_name, username, role, created_at) VALUES (?, ?, ?, ?, ?)",
            (user_id, full_name, username, role, datetime.now().strftime("%Y-%m-%d %H:%M")),
        )
    elif role:
        cursor.execute("UPDATE users SET role = ?, full_name = ? WHERE user_id = ?", (role, full_name, user_id))
    conn.commit()
    conn.close()


def get_user_role(user_id: int) -> str:
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT role FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return row[0] if row and row[0] else "abituriyent"


def save_question(user_id: int, full_name: str, text: str, answer: str = None, status: str = "open") -> int:
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO questions (user_id, full_name, question_text, answer_text, status, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, full_name, text, answer, status, datetime.now().strftime("%Y-%m-%d %H:%M")),
    )
    q_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return q_id


def mark_question_answered(q_id: int, answer: str, status: str = "answered"):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE questions SET answer_text = ?, status = ? WHERE id = ?",
        (answer, status, q_id),
    )
    conn.commit()
    conn.close()


# ==========================================
# 3. AVTO-OPERATOR BILIMLAR BAZASI
# ==========================================
AUTO_FAQ_BASE = [
    {
        "keywords": ["kontrakt", "to'lov", "tolov", "shartnoma", "super", "tabaqalashtirilgan", "pul"],
        "answer": (
            "💰 <b>Kontrakt to‘lovi bo‘yicha ma’lumot:</b>\n"
            "• Kontrakt shartnomasini <code>kontrakt.edu.uz</code> saytidan JSHSHIR orqali yuklab olishingiz mumkin.\n"
            "• To‘lovni o‘quv yili davomida kamida <b>4 qismga bo‘lib</b> to‘lashga ruxsat beriladi (1-chorak — 25% oktyabrgacha, 2-chorak — 50% yanvargacha, 3-chorak — 75% martgacha, 4-chorak — 100% maygacha).\n"
            "• To‘lov muddati bo‘yicha muammo bo‘lsa, rektor nomiga ariza yozib muddatni uzaytirish mumkin."
        ),
    },
    {
        "keywords": ["stipendiya", "stependiya", "oylik", "karta", "beshlik", "5 lik", "oshirilgan"],
        "answer": (
            "💳 <b>Stipendiya bo‘yicha ma’lumot:</b>\n"
            "• Stipendiya har oyning <b>5–10-sanalari</b> oralig‘ida talabaning plastik kartasiga o‘tkaziladi.\n"
            "• Semestr yakunida barcha fanlardan «5» (86+ ball) olgan grant talabalariga <b>20% oshirilgan stipendiya</b> tayinlanadi.\n"
            "• Akademik qarzdorligi (2 baho / F) bor talabalarga stipendiya to‘xtatiladi va qarzdorlik yopilgan oydan keyingi oydan qayta tiklanadi."
        ),
    },
    {
        "keywords": ["gpa", "ball", "o'tish", "otish", "kursdan", "yiqil", "qarzdor"],
        "answer": (
            "📊 <b>GPA va kursdan kursga o‘tish tartibi:</b>\n"
            "• Talaba keyingi kursga o‘tishi uchun o‘quv yili yakunida o‘tish GPA balini (odatda <b>2.4 – 2.6</b>) to‘plashi kerak.\n"
            "• GPA yetmagan yoki qarzdor fanlari qolgan talabalar yozgi semestrda (Retake) fanlarni qayta topshirib balini ko‘tarishi mumkin.\n"
            "• Aniq GPA balingizni hisoblash uchun menyudagi <b>«🧮 GPA kalkulyatori»</b> tugmasidan foydalaning."
        ),
    },
    {
        "keywords": ["retake", "riteyk", "yozgi", "qayta", "2 baho", "f fan"],
        "answer": (
            "📚 <b>Retake (qayta o‘qish) tartibi:</b>\n"
            "• 56 balldan kam to‘plangan yoki NB sababli yakuniyga kiritilmagan fanlar <b>yozgi semestrda (Retake)</b> qayta o‘zlashtiriladi.\n"
            "• 1 kredit narxi = (Yillik bazaviy kontrakt summasi ÷ 60) × fan krediti formulasi asosida hisoblanadi.\n"
            "• Ariza dekanat orqali semestr yakunlangandan so‘ng beriladi."
        ),
    },
    {
        "keywords": ["hemis", "xemis", "parol", "login", "nb", "davomat", "kabinet"],
        "answer": (
            "💻 <b>HEMIS tizimi bo‘yicha yordam:</b>\n"
            "• Login yoki parol unutgan bo‘lsangiz, fakultet dekanati yoki OTMning IT (Raqamli ta’lim) bo‘limiga pasport bilan murojaat qilib tiklatishingiz mumkin.\n"
            "• Bir fandan auditoriya soatlarining <b>25% dan ko‘pi</b> sababsiz qoldirilsa (NB), talaba yakuniy nazoratga kiritilmaydi."
        ),
    },
    {
        "keywords": ["perevod", "ko'chirish", "kochirish", "tiklash", "xorijiy", "nodavlat"],
        "answer": (
            "🔄 <b>O‘qishni ko‘chirish (Perevod) tartibi:</b>\n"
            "• Yozgi perevod uchun arizalar har yili <b>15-iyuldan 5-avgustgacha</b> <code>transfer.edu.uz</code> yoki <code>my.uzbmb.uz</code> orqali qabul qilinadi.\n"
            "• Xorijiy va nodavlat OTMlardan davlat OTMlariga o‘tishda maxsus test sinovidan o‘tish talab etiladi.\n"
            "• Turmush qurish yoki ota-onaning xizmat joyi o‘zgarishi sababli qishki perevod (20-dekabr – 20-yanvar) ham mavjud."
        ),
    },
    {
        "keywords": ["akademik", "ta'til", "tatil", "armiya", "harbiy", "kasallik"],
        "answer": (
            "⏸ <b>Akademik ta’til olish tartibi:</b>\n"
            "• Salomatlikni tiklash (tibbiy komissiya xulosasi asosida), homiladorlik va tug‘ish ta’tili yoki harbiy xizmatga chaqirilish munosabati bilan <b>1 yilgacha</b> akademik ta’til beriladi.\n"
            "• Buning uchun rektor nomiga ariza va tasdiqlovchi hujjat dekanatga topshiriladi."
        ),
    },
    {
        "keywords": ["ttj", "yotoqxona", "yotoq", "turar joy"],
        "answer": (
            "🏠 <b>Talabalar turar joyi (TTJ) ga joylashish:</b>\n"
            "• Ariza <code>my.gov.uz</code> (Yagona interaktiv davlat xizmatlari portali) orqali onlayn topshiriladi.\n"
            "• 1-kurs talabalari, chin yetimlar, nogironligi bo‘lganlar va ijtimoiy himoya reyestridagi oila farzandlariga birinchi navbatda o‘rin ajratiladi."
        ),
    },
    {
        "keywords": ["ijara", "kvartira", "kompensatsiya", "50%", "50 foiz"],
        "answer": (
            "🏡 <b>Ijara to‘lovi kompensatsiyasi:</b>\n"
            "• TTJ bilan ta’minlanmagan kunduzgi bo‘lim talabalariga ijara shartnomasi (<code>ijara.soliq.uz</code> dan ro‘yxatdan o‘tgan) asosida oylik ijara pulining <b>50% qismi</b> davlat tomonidan qaytariladi.\n"
            "• Ariza har oyning 7-sanasigacha HEMIS tizimi yoki fakultet tyutori orqali topshiriladi."
        ),
    },
    {
        "keywords": ["grant", "byudjet", "budjet", "imtiyoz", "daftar"],
        "answer": (
            "🎓 <b>Grantga o‘tish va imtiyozlar:</b>\n"
            "• O‘quv yili yakunida yuqori GPA (odatda 3.5+) to‘plagan kontrakt talabalari bo‘shagan davlat granti o‘rinlariga tanlov asosida o‘tkaziladi.\n"
            "• Ariza o‘quv yili oxirida (iyul oyida) OTM kengashiga topshiriladi."
        ),
    },
    {
        "keywords": ["kredit", "bank", "foizsiz", "0%"],
        "answer": (
            "🏦 <b>Ta’lim krediti shartlari:</b>\n"
            "• Kunduzgi bo‘lim talabalari <code>talim-krediti.mf.uz</code> platformasi orqali banklardan imtiyozli ta’lim krediti olishi mumkin.\n"
            "• Xotin-qizlar uchun kredit <b>0% (foizsiz)</b>, yigitlar uchun Markaziy bank asosiy stavkasida beriladi. Kredit o‘qish tugagandan 7 oy o‘tib, 7 yil davomida qaytariladi."
        ),
    },
    {
        "keywords": ["ma'lumotnoma", "malumotnoma", "spravka", "transkript", "hujjat", "attestat", "diplom"],
        "answer": (
            "📄 <b>Ma’lumotnoma va hujjatlarni olish:</b>\n"
            "• O‘qish joyidan ma’lumotnomani dekanatga bormasdan <code>my.gov.uz</code> yoki HEMIS shaxsiy kabinetidagi <i>«Talaba ma’lumotnomasi»</i> bo‘limidan QR-kodli shaklda 1 daqiqada yuklab olishingiz mumkin.\n"
            "• Transkript (baholar ko‘chirmasi) Registrator ofisi yoki dekanat orqali 3 ish kunida beriladi."
        ),
    },
    {
        "keywords": ["qabul", "dtm", "uzbmb", "test", "ro'yxat", "royxat", "mandat", "yo'nalish", "yonalish"],
        "answer": (
            "📅 <b>Qabul va test jarayoni:</b>\n"
            "• Abituriyentlarni ro‘yxatga olish <code>my.uzbmb.uz</code> sayti orqali onlayn o‘tkaziladi.\n"
            "• «Avval test, so‘ng tanlov» tamoyili asosida test natijasi chiqqandan keyin 15 kun ichida 5 tagacha yo‘nalish tanlanadi.\n"
            "• Grant uchun minimal ball — <b>68,0</b>, kontrakt uchun — <b>56,7</b>."
        ),
    },
    {
        "keywords": ["ielts", "cefr", "sertifikat", "ingliz", "chet tili"],
        "answer": (
            "🌐 <b>Chet tili sertifikati imtiyozi:</b>\n"
            "• Milliy sertifikat (B2 va undan yuqori) yoki xalqaro IELTS (5.5+), TOEFL, Goethe, DELF sertifikatlari mavjud abituriyentlarga chet tili fanidan maksimal ball beriladi.\n"
            "• Sertifikatni ro‘yxatdan o‘tish vaqtida <code>my.uzbmb.uz</code> bazasiga yuklash shart."
        ),
    },
    {
        "keywords": ["imtihon", "oraliq", "yakuniy", "apellyatsiya", "apelyatsiya", "nazorat"],
        "answer": (
            "📝 <b>Imtihon va apellyatsiya tartibi:</b>\n"
            "• Yakuniy nazorat bahosidan norozi bo‘lsangiz, natija e’lon qilingan vaqtdan boshlab <b>24 soat ichida</b> HEMIS tizimi orqali yoki fakultet apellyatsiya komissiyasiga ariza berishingiz mumkin.\n"
            "• Uzrli sabab (kasallik varaqasi) bilan imtihonga kira olmagan talabaga dekanat ruxsati bilan qayta topshirish kuni belgilanadi."
        ),
    },
    {
        "keywords": ["amaliyot", "bmi", "diplom ishi", "antiplagiat", "himoya", "stajirovka"],
        "answer": (
            "💼 <b>Amaliyot va Bitiruv malakaviy ishi (BMI):</b>\n"
            "• Amaliyot kundaligi va hisoboti HEMIS tizimiga elektron yuklanadi.\n"
            "• BMI himoyadan oldin <b>Antiplagiat</b> tizimida tekshiriladi va matnning o‘ziga xosligi kamida 65–70% bo‘lishi talab etiladi."
        ),
    },
    {
        "keywords": ["salom", "assalom", "rahmat", "raxmat"],
        "answer": (
            "👋 Va alaykum assalom! Sizga yordam berishdan mamnunman.\n"
            "Kontrakt, stipendiya, GPA, HEMIS, perevod, TTJ yoki qabul bo‘yicha aniq savolingizni yozing — darhol javob beraman!"
        ),
    },
]


def get_auto_reply(question_text: str) -> str | None:
    normalized = (
        question_text.lower()
        .replace("‘", "'")
        .replace("’", "'")
        .replace("`", "'")
    )
    best_answer = None
    best_score = 0

    for item in AUTO_FAQ_BASE:
        score = sum(1 for kw in item["keywords"] if kw in normalized)
        if score > best_score:
            best_score = score
            best_answer = item["answer"]

    return best_answer if best_score > 0 else None


# ==========================================
# 4. HOLATLAR (FSM STATES)
# ==========================================
class DirectionQuiz(StatesGroup):
    choosing_block = State()
    choosing_goal = State()


class GPAState(StatesGroup):
    waiting_grades = State()


class QuestionState(StatesGroup):
    waiting_question = State()


class AdminReplyState(StatesGroup):
    waiting_reply = State()


# ==========================================
# 5. KLAVIATURA VA TUGMALAR
# ==========================================
def role_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🎓 Abituriyentman"), KeyboardButton(text="🧑‍🎓 Talabaman")],
        ],
        resize_keyboard=True,
    )


def abituriyent_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🎯 Yo‘nalish tanlash maslahatchisi")],
            [KeyboardButton(text="📅 Qabul va hujjatlar"), KeyboardButton(text="💰 Kontrakt va imtiyozlar")],
            [KeyboardButton(text="🏛 OTMlar va o‘tish ballari"), KeyboardButton(text="✍️ Operatorga savol berish")],
            [KeyboardButton(text="🔄 Rolni o‘zgartirish")],
        ],
        resize_keyboard=True,
    )


def talaba_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🧮 GPA kalkulyatori va maslahat")],
            [KeyboardButton(text="📚 Kredit-modul va Retake"), KeyboardButton(text="💻 HEMIS va shaxsiy kabinet")],
            [KeyboardButton(text="🔄 Perevod va akademik ta’til"), KeyboardButton(text="📄 Ma’lumotnoma va hujjatlar")],
            [KeyboardButton(text="🏠 TTJ, ijara va stipendiya"), KeyboardButton(text="🎓 Grant va ta’lim krediti")],
            [KeyboardButton(text="📝 Imtihon va apellyatsiya"), KeyboardButton(text="💼 Amaliyot va diplom ishi")],
            [KeyboardButton(text="✍️ Operatorga savol berish"), KeyboardButton(text="🔄 Rolni o‘zgartirish")],
        ],
        resize_keyboard=True,
    )


def menu_by_user(user_id: int):
    return talaba_menu() if get_user_role(user_id) == "talaba" else abituriyent_menu()


def cancel_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="❌ Bekor qilish")]],
        resize_keyboard=True,
    )


# ==========================================
# 6. UMUMIY VA START HANDLERLARI
# ==========================================
@dp.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    save_user(message.from_user.id, message.from_user.full_name, message.from_user.username or "")
    await message.answer(
        f"Assalomu alaykum, <b>{message.from_user.first_name}</b>!\n\n"
        "<b>@EduMaslahat_bot</b> — abituriyent va talabalar uchun aqlli maslahat tizimiga xush kelibsiz.\n"
        "Davom etish uchun maqomingizni tanlang:",
        reply_markup=role_keyboard(),
    )


@dp.message(F.text == "🔄 Rolni o‘zgartirish")
async def change_role(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Yangi maqomingizni tanlang:", reply_markup=role_keyboard())


@dp.message(F.text == "❌ Bekor qilish")
async def cancel_action(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Amal bekor qilindi. Asosiy menyudasiz:", reply_markup=menu_by_user(message.from_user.id))


# ==========================================
# 7. ABITURIYENT BO'LIMI
# ==========================================
@dp.message(F.text == "🎓 Abituriyentman")
async def select_abituriyent(message: Message, state: FSMContext):
    await state.clear()
    save_user(message.from_user.id, message.from_user.full_name, message.from_user.username or "", "abituriyent")
    await message.answer(
        "🎓 <b>Abituriyentlar bo‘limi</b>\nKerakli yo‘nalishni tanlang:",
        reply_markup=abituriyent_menu(),
    )


@dp.message(F.text == "🎯 Yo‘nalish tanlash maslahatchisi")
async def direction_quiz_start(message: Message, state: FSMContext):
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="Matematika + Fizika / Informatika")],
            [KeyboardButton(text="Kimyo + Biologiya")],
            [KeyboardButton(text="Tarix + Ona tili / Chet tili")],
            [KeyboardButton(text="Matematika + Ingliz tili")],
            [KeyboardButton(text="❌ Bekor qilish")],
        ],
        resize_keyboard=True,
    )
    await state.set_state(DirectionQuiz.choosing_block)
    await message.answer("1-qadam: Qaysi asosiy fanlar blokiga tayyorlanyapsiz?", reply_markup=kb)


@dp.message(DirectionQuiz.choosing_block)
async def direction_quiz_block(message: Message, state: FSMContext):
    await state.update_data(block=message.text)
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="Yuqori maoshli IT / Texnika soha")],
            [KeyboardButton(text="Davlat granti ehtimoli yuqori yo‘nalish")],
            [KeyboardButton(text="Pedagogika yoki gumanitar soha")],
            [KeyboardButton(text="❌ Bekor qilish")],
        ],
        resize_keyboard=True,
    )
    await state.set_state(DirectionQuiz.choosing_goal)
    await message.answer("2-qadam: Siz uchun eng muhim mezon qaysi?", reply_markup=kb)


@dp.message(DirectionQuiz.choosing_goal)
async def direction_quiz_result(message: Message, state: FSMContext):
    data = await state.get_data()
    block = data.get("block", "")
    await state.clear()

    recommendations = {
        "Matematika + Fizika / Informatika": (
            "• <b>Dasturiy injiniring va Kiberxavfsizlik</b> (TATU, Inha, NewUU)\n"
            "• <b>Sun’iy intellekt va Data Science</b>\n"
            "• <b>Energetika va muhandislik texnologiyalari</b> (TDTU — grant kvotalari ko‘p)"
        ),
        "Kimyo + Biologiya": (
            "• <b>Davolash ishi va Pediatriya</b> (TTA, SamDTU)\n"
            "• <b>Farmatsiya va Biotexnologiya</b> (O‘zMU, Farmatsevtika instituti)\n"
            "• <b>Ekologiya va oziq-ovqat texnologiyasi</b> (grant imkoniyati yuqori)"
        ),
        "Tarix + Ona tili / Chet tili": (
            "• <b>Yurisprudensiya</b> (TDYU)\n"
            "• <b>Filologiya va tillarni o‘qitish</b> (O‘zDJTU, TDO‘TAU)\n"
            "• <b>Xalqaro munosabatlar va siyosatshunoslik</b> (JIDU)"
        ),
        "Matematika + Ingliz tili": (
            "• <b>Moliya, Bank ishi va Audit</b> (TDIU)\n"
            "• <b>Raqamli iqtisodiyot va Biznes tahlil</b>\n"
            "• <b>Xalqaro logistika va menejment</b>"
        ),
    }

    rec_text = recommendations.get(
        block,
        "• Tanlangan fanlar bo‘yicha 5 tagacha yo‘nalishni ustuvorlik tartibida belgilash tavsiya etiladi.",
    )

    await message.answer(
        f"🎯 <b>Siz uchun tavsiya etilgan yo‘nalishlar:</b>\n\n"
        f"<b>Blok:</b> {block}\n"
        f"<b>Maqsad:</b> {message.text}\n\n"
        f"{rec_text}\n\n"
        "💡 <i>Maslahat:</i> 1-ustuvorlikka orzuingizdagi OTMni, 4–5-o‘rinlarga esa o‘tish bali nisbatan pastroq hududiy OTMlarni qo‘ying.",
        reply_markup=abituriyent_menu(),
    )


@dp.message(F.text == "📅 Qabul va hujjatlar")
async def abituriyent_docs(message: Message):
    await message.answer(
        "📅 <b>Qabul jarayoni va kerakli hujjatlar:</b>\n\n"
        "1. <b>Ro‘yxatdan o‘tish:</b> <code>my.uzbmb.uz</code> platformasi orqali onlayn amalga oshiriladi (odatda 5-iyundan 25-iyungacha).\n"
        "2. <b>Kerakli ma’lumotlar:</b> Pasport (ID karta) JSHSHIR raqami, maktab/kollej attestati seriyasi va raqami.\n"
        "3. <b>Chet tili sertifikati:</b> IELTS, CEFR (B2 va undan yuqori) bo‘lsa, tizimga yuklab maksimal ball olish mumkin.\n"
        "4. <b>Tanlov tartibi:</b> «Avval test, so‘ng tanlov» tamoyili asosida test balli chiqqandan keyin 15 kun ichida 5 tagacha yo‘nalish tanlanadi."
    )


@dp.message(F.text == "💰 Kontrakt va imtiyozlar")
async def abituriyent_contract(message: Message):
    await message.answer(
        "💰 <b>To‘lov-kontrakt va imtiyozlar:</b>\n\n"
        "• <b>Bo‘lib to‘lash:</b> Kontrakt summasini o‘quv yili davomida kamida 4 qismga bo‘lib to‘lash mumkin (1-chorak uchun kamida 25% oktyabrgacha).\n"
        "• <b>Ta’lim krediti:</b> Kunduzgi bo‘lim talabalari uchun Markaziy bank asosiy stavkasida (xotin-qizlar uchun 0% foizsiz) banklardan ta’lim krediti ajratiladi.\n"
        "• <b>Imtiyozlar:</b> «Temir daftar», «Ayollar daftari», «Yoshlar daftari»ga kirgan oila farzandlari hamda I–II guruh nogironligi bo‘lgan abituriyentlar uchun qo‘shimcha kvota va imtiyozlar mavjud."
    )


@dp.message(F.text == "🏛 OTMlar va o‘tish ballari")
async def abituriyent_universities(message: Message):
    await message.answer(
        "🏛 <b>OTMlar va o‘tish ballari bo‘yicha ma’lumot:</b>\n\n"
        "• <b>Minimal o‘tish bali:</b> Davlat granti uchun kamida <b>68,0 ball</b>, to‘lov-kontrakt uchun kamida <b>56,7 ball</b> to‘plash talab etiladi.\n"
        "• <b>Eng raqobatli OTMlar:</b> TDYU, JIDU, TTA, TATU, TDIU va O‘zMU (grant ballari o‘rtacha 155–189 ball atrofida).\n"
        "• <b>Tekshirish:</b> Har bir yo‘nalishning o‘tgan yilgi aniq o‘tish ballarini <code>mandat.uzbmb.uz</code> saytidan ko‘rish mumkin."
    )


# ==========================================
# 8. TALABA BO'LIMI (9 TA MODUL)
# ==========================================
@dp.message(F.text == "🧑‍🎓 Talabaman")
async def select_talaba(message: Message, state: FSMContext):
    await state.clear()
    save_user(message.from_user.id, message.from_user.full_name, message.from_user.username or "", "talaba")
    await message.answer(
        "🧑‍🎓 <b>Talabalar maslahat markazi</b>\n"
        "O‘quv jarayoni, HEMIS, stipendiya, grant yoki hujjatlar bo‘yicha kerakli bo‘limni tanlang:",
        reply_markup=talaba_menu(),
    )


@dp.message(F.text == "🧮 GPA kalkulyatori va maslahat")
async def gpa_start(message: Message, state: FSMContext):
    await state.set_state(GPAState.waiting_grades)
    await message.answer(
        "🧮 <b>GPA Hisoblash Kalkulyatori</b>\n\n"
        "Fanlardan olgan <b>bahoyingiz</b> va <b>kredit sonini</b> vergul bilan ajratib yozing.\n"
        "<i>5 ballik tizimda yoki 100 ballik tizimda kiritishingiz mumkin:</i>\n\n"
        "📌 <b>Misol 1 (5 ballik):</b> <code>5 4, 4 6, 5 3, 3 4</code>\n"
        "📌 <b>Misol 2 (100 ballik):</b> <code>90 4, 78 6, 86 3, 65 4</code>\n"
        "<i>(Bu yerda birinchi son — baho, ikkinchi son — fan krediti)</i>",
        reply_markup=cancel_keyboard(),
    )


@dp.message(GPAState.waiting_grades)
async def gpa_calculate(message: Message, state: FSMContext):
    try:
        pairs = [item.strip() for item in message.text.split(",") if item.strip()]
        total_points = 0.0
        total_credits = 0.0

        for pair in pairs:
            parts = pair.split()
            if len(parts) != 2:
                raise ValueError("Format xato")
            grade = float(parts[0])
            credit = float(parts[1])
            if credit <= 0:
                raise ValueError("Kredit musbat bo'lishi kerak")

            if grade > 5:
                if grade >= 86:
                    gpa_grade = 4.0
                elif grade >= 71:
                    gpa_grade = 3.0
                elif grade >= 56:
                    gpa_grade = 2.0
                else:
                    gpa_grade = 0.0
            else:
                if grade >= 5:
                    gpa_grade = 4.0
                elif grade >= 4:
                    gpa_grade = 3.0
                elif grade >= 3:
                    gpa_grade = 2.0
                else:
                    gpa_grade = 0.0

            total_points += gpa_grade * credit
            total_credits += credit

        if total_credits == 0:
            raise ValueError("Kredit nolga teng")

        gpa = round(total_points / total_credits, 2)

        if gpa >= 3.5:
            advice = "🌟 <b>A’lo natija!</b> Grantga da’vogarlik qilish va oshirilgan stipendiya olish imkoniyatingiz juda yuqori."
        elif gpa >= 2.6:
            advice = "✅ <b>Yaxshi ko‘rsatkich!</b> Kursdan kursga muammosiz o‘tasiz. Keyingi semestrda 3.5+ ga harakat qiling."
        elif gpa >= 2.4:
            advice = "⚠️ <b>Chegara holat!</b> O‘tish baliga yaqinsiz, qarzdor fanlar qolmasligiga e’tibor bering."
        else:
            advice = "🚨 <b>Diqqat!</b> GPA 2.4 dan past — kursda qolish xavfi bor. Yozgi semestr (Retake) orqali past baholarni qayta topshiring."

        await state.clear()
        await message.answer(
            f"📊 <b>Sizning GPA natijangiz:</b> <code>{gpa} / 4.00</code>\n"
            f"📚 <b>Jami kreditlar:</b> {int(total_credits) if total_credits.is_integer() else total_credits}\n\n"
            f"{advice}",
            reply_markup=talaba_menu(),
        )
    except Exception:
        await message.answer(
            "❌ Format noto‘g‘ri kiritildi. Iltimos, namunadagidek yozing:\n"
            "<code>5 4, 4 6, 3 4</code> (baho va kredit orasida probel, fanlar orasida vergul)."
        )


@dp.message(F.text == "📚 Kredit-modul va Retake")
async def talaba_credit_module(message: Message):
    await message.answer(
        "📚 <b>Kredit-modul tizimi va Retake tartibi:</b>\n\n"
        "• <b>1 kredit:</b> O‘rtacha 30 akademik soat o‘quv yuklamasiga teng (auditoriya + mustaqil ta’lim). Bir o‘quv yilida odatda <b>60 kredit</b> o‘zlashtiriladi.\n"
        "• <b>Baholash:</b> 86–100 ball = 5 (A), 71–85 ball = 4 (B), 56–70 ball = 3 (C), 56 balldan kam = 2 (F — akademik qarzdorlik).\n"
        "• <b>Retake (qayta o‘qish):</b> Yiqilgan fanni yozgi semestrda yoki keyingi o‘quv yilida shartnoma asosida qayta o‘zlashtirish mumkin.\n"
        "• <b>Retake narxi:</b> 1 kredit narxi = (Yillik bazaviy kontrakt summasi ÷ 60) × fan krediti."
    )


@dp.message(F.text == "💻 HEMIS va shaxsiy kabinet")
async def talaba_hemis(message: Message):
    await message.answer(
        "💻 <b>HEMIS tizimi bo‘yicha asosiy yo‘riqnoma:</b>\n\n"
        "1. <b>Login va parol unutulsa:</b> Fakultet dekanati yoki OTMning Raqamli ta’lim texnologiyalari markaziga (IT bo‘lim) pasport bilan murojaat qilib parolni tiklatish mumkin.\n"
        "2. <b>Davomat (NB):</b> Bir fandan ajratilgan auditoriya soatlarining <b>25% dan ortig‘i</b> sababsiz qoldirilsa, talaba yakuniy nazoratga kiritilmaydi.\n"
        "3. <b>Tanlov fanlari:</b> Semestr boshida HEMIS kabinetidagi <i>«O‘quv reja → Tanlov fanlari»</i> bo‘limidan o‘zingizga mos fanni belgilashni unutmang.\n"
        "4. <b>Reyting daftarchasi:</b> Barcha joriy, oraliq va yakuniy ballaringizni <i>«O‘zlashtirish»</i> bo‘limidan real vaqtda kuzatib borishingiz mumkin."
    )


@dp.message(F.text == "🔄 Perevod va akademik ta’til")
async def talaba_perevod(message: Message):
    await message.answer(
        "🔄 <b>O‘qishni ko‘chirish (Perevod) va Akademik ta’til:</b>\n\n"
        "• <b>Ariza topshirish muddati:</b> Har yili <b>15-iyuldan 5-avgustgacha</b> <code>transfer.edu.uz</code> (davlat OTMlariaro) yoki <code>my.uzbmb.uz</code> (xorijiy va nodavlat OTMlardan) orqali.\n"
        "• <b>Uzrli sabablar:</b> Turmush qurish (boshqa hududga ko‘chish) yoki ota-onaning ish joyi o‘zgarishi sababli qishki perevod (20-dekabr – 20-yanvar) ham mavjud.\n"
        "• <b>Akademik ta’til:</b> Salomatlik yomonlashganda, homiladorlik va tug‘ish ta’tilida yoki harbiy xizmatga chaqirilganda rektor buyrug‘i bilan 1 yilgacha beriladi."
    )


@dp.message(F.text == "📄 Ma’lumotnoma va hujjatlar")
async def talaba_documents(message: Message):
    await message.answer(
        "📄 <b>Ma’lumotnoma va rasmiy hujjatlarni olish:</b>\n\n"
        "1. <b>O‘qish joyidan ma’lumotnoma:</b> Dekanatga bormasdan <code>my.gov.uz</code> (Yagona portal) yoki HEMIS shaxsiy kabinetidagi <i>«Talaba ma’lumotnomasi»</i> bo‘limidan QR-kodli shaklda 1 daqiqada yuklab olinadi.\n"
        "2. <b>Kontrakt shartnomasi:</b> <code>kontrakt.edu.uz</code> platformasidan JSHSHIR orqali yuklab olinadi.\n"
        "3. <b>Transkript / Akademik ma’lumotnoma:</b> Barcha o‘zlashtirilgan fanlar va kreditlar ro‘yxati yozilgan transkript dekanat yoki Registrator ofisi orqali 3 ish kunida beriladi."
    )


@dp.message(F.text == "🏠 TTJ, ijara va stipendiya")
async def talaba_dorm_stipend(message: Message):
    await message.answer(
        "🏠 <b>TTJ (Yotoqxona), Ijara kompensatsiyasi va Stipendiya:</b>\n\n"
        "• <b>TTJga joylashish:</b> <code>my.gov.uz</code> orqali onlayn ariza yuboriladi. 1-kurslar, chin yetimlar va ijtimoiy himoyaga muhtoj talabalar ustuvor joylashtiriladi.\n"
        "• <b>Ijara to‘lovi kompensatsiyasi:</b> Yotoqxona bilan ta’minlanmagan kunduzgi bo‘lim talabalariga ijara shartnomasi asosida oylik ijara pulining <b>50% qismi</b> (Toshkentda BHMning 1 baravarigacha, viloyatlarda 0.5 baravarigacha) davlat byudjetidan qaytariladi.\n"
        "• <b>Stipendiya turlari:</b> Bazaviy stipendiya (barcha fanlari 3 va undan yuqori grant talabalariga), 20% oshirilgan stipendiya (barcha fanlari «5» a’lo bo‘lganlarga) hamda nomdor stipendiyalar (Prezident, Navoiy, Beruniy, Islom Karimov)."
    )


@dp.message(F.text == "🎓 Grant va ta’lim krediti")
async def talaba_grant_credit(message: Message):
    await message.answer(
        "🎓 <b>Kontraktdan grantga o‘tish va Ta’lim krediti:</b>\n\n"
        "• <b>Grantga o‘tish tartibi:</b> O‘quv yili yakunida GPA ko‘rsatkichi yuqori bo‘lgan kontrakt talabalari bo‘shagan davlat granti o‘rinlariga tanlov asosida o‘tkaziladi (GPA kamida 3.5+ bo‘lishi tavsiya etiladi).\n"
        "• <b>Ta’lim krediti:</b> Kunduzgi bo‘lim talabalari istalgan tijorat bankidan (<code>talim-krediti.mf.uz</code> orqali) imtiyozli ta’lim krediti olishi mumkin. Kredit o‘qish tugagandan 7 oy o‘tib, 7 yil davomida qaytariladi.\n"
        "• <b>Xotin-qizlar uchun:</b> Magistratura bosqichidagi barcha xotin-qizlarning kontrakt to‘lovi davlat byudjeti hisobidan to‘liq qoplab beriladi."
    )


@dp.message(F.text == "📝 Imtihon va apellyatsiya")
async def talaba_exams(message: Message):
    await message.answer(
        "📝 <b>Imtihonlar va apellyatsiya tartibi:</b>\n\n"
        "• <b>Yakuniy nazoratga kirish:</b> Oraliq va joriy nazoratlardan yetarli ball to‘plagan hamda dars qoldirish limiti (25%) oshmagan talabalar kiritiladi.\n"
        "• <b>Uzrli sabab bilan qoldirish:</b> Kasallik (tibbiy ma’lumotnoma) yoki yaqin qarindosh vafoti sababli imtihonga kira olmagan talabaga dekanat ruxsati bilan qayta topshirish muddati belgilanadi.\n"
        "• <b>Apellyatsiya:</b> Yakuniy nazorat bahosidan norozi bo‘lsangiz, natija e’lon qilingan kundan boshlab <b>24 soat (1 ish kuni) ichida</b> HEMIS tizimi orqali yoki fakultet apellyatsiya komissiyasiga ariza berishingiz mumkin."
    )


@dp.message(F.text == "💼 Amaliyot va diplom ishi")
async def talaba_internship(message: Message):
    await message.answer(
        "💼 <b>Amaliyot, BMI va Karyera markazi:</b>\n\n"
        "• <b>Ishlab chiqarish amaliyoti:</b> 3- va 4-kurs talabalari uch tomonlama shartnoma asosida korxona va tashkilotlarda amaliyot o‘taydi. Amaliyot kundaligi va hisoboti HEMIS tizimiga yuklanadi.\n"
        "• <b>Bitiruv malakaviy ishi (BMI):</b> Mavzu 4-kurs boshida kafedra tomonidan tasdiqlanadi. Himoyadan oldin ish <b>Antiplagiat</b> tizimida tekshiriladi (o‘ziga xoslik kamida 65–70% bo‘lishi talab etiladi).\n"
        "• <b>Ishga joylashish:</b> OTMning Karyera markazi orqali bitiruvchi kurs talabalari uchun bo‘sh ish o‘rinlari yarmarkalari va stajirovkalar tashkil etiladi."
    )


# ==========================================
# 9. AVTO-OPERATOR VA JONLI OPERATOR TIZIMI
# ==========================================
async def forward_to_admins(user_id: int, full_name: str, username: str | None, q_id: int, text: str):
    reply_markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💬 Javob yozish",
                    callback_data=f"reply_to:{user_id}:{q_id}",
                )
            ]
        ]
    )
    username_str = f"@{username}" if username else "yo‘q"
    admin_text = (
        f"📩 <b>Jonli operatorga savol keldi! (#{q_id})</b>\n\n"
        f"👤 <b>Foydalanuvchi:</b> {full_name} ({username_str})\n"
        f"🆔 <b>ID:</b> <code>{user_id}</code>\n"
        f"❓ <b>Savol:</b> {text}\n\n"
        f"<i>Javob berish uchun tugmani bosing yoki:</i>\n"
        f"<code>/reply {user_id} Javob matni</code>"
    )
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, admin_text, reply_markup=reply_markup)
        except Exception as e:
            logging.error(f"Adminga yuborishda xatolik ({admin_id}): {e}")


@dp.message(F.text == "✍️ Operatorga savol berish")
async def ask_operator_start(message: Message, state: FSMContext):
    await state.set_state(QuestionState.waiting_question)
    await message.answer(
        "🤖 <b>Avto-Operator va Qabul markazi</b>\n\n"
        "Savolingizni yozib yuboring — tizim darhol avtomatik javob beradi yoki zarur bo‘lsa jonli operatorga ulaydi:",
        reply_markup=cancel_keyboard(),
    )


@dp.message(QuestionState.waiting_question)
async def ask_operator_receive(message: Message, state: FSMContext):
    await state.clear()
    user_kb = menu_by_user(message.from_user.id)
    auto_reply = get_auto_reply(message.text)

    if auto_reply:
        q_id = save_question(
            message.from_user.id,
            message.from_user.full_name,
            message.text,
            answer=auto_reply,
            status="auto_answered",
        )
        escalate_kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="👨‍💼 Jonli operatorga yuborish",
                        callback_data=f"escalate:{q_id}",
                    )
                ]
            ]
        )
        await message.answer(
            f"🤖 <b>Avto-Operator javobi (#{q_id}):</b>\n\n"
            f"{auto_reply}\n\n"
            "<i>💡 Agar javob savolingizni to‘liq qamrab olmagan bo‘lsa, pastdagi tugma orqali jonli operatorga yuborishingiz mumkin:</i>",
            reply_markup=escalate_kb,
        )
        await message.answer("Yana savolingiz bo‘lsa, menyudan tanlang:", reply_markup=user_kb)
    else:
        q_id = save_question(
            message.from_user.id,
            message.from_user.full_name,
            message.text,
            status="open",
        )
        await message.answer(
            f"🤖 <b>Avto-Operator (#{q_id}):</b>\n\n"
            "Savolingiz individual ko‘rib chiqishni talab qiladi. Uni hoziroq jonli dekanat/qabul operatoriga yo‘naltirdim — tez orada shu yerga javob keladi!",
            reply_markup=user_kb,
        )
        await forward_to_admins(
            message.from_user.id,
            message.from_user.full_name,
            message.from_user.username,
            q_id,
            message.text,
        )


@dp.callback_query(F.data.startswith("escalate:"))
async def escalate_to_human(callback: CallbackQuery):
    q_id = int(callback.data.split(":")[1])
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("SELECT user_id, full_name, question_text, status FROM questions WHERE id = ?", (q_id,))
    row = cur.fetchone()
    if row:
        cur.execute("UPDATE questions SET status = 'open' WHERE id = ?", (q_id,))
        conn.commit()
    conn.close()

    if not row:
        await callback.answer("Savol topilmadi.", show_alert=True)
        return

    user_id, full_name, question_text, _ = row
    await forward_to_admins(user_id, full_name, callback.from_user.username, q_id, question_text)
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(
        f"✅ <b>#{q_id}-savol</b> jonli operatorga yuborildi. Operator javob yozishi bilan xabar shu yerga keladi."
    )
    await callback.answer("Jonli operatorga yuborildi!")


@dp.callback_query(F.data.startswith("reply_to:"))
async def admin_reply_button(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Sizda admin huquqi yo‘q!", show_alert=True)
        return

    _, target_user_id, q_id = callback.data.split(":")
    await state.set_state(AdminReplyState.waiting_reply)
    await state.update_data(target_user_id=int(target_user_id), q_id=int(q_id))

    await callback.message.answer(
        f"💬 <b>#{q_id}-savol</b> (ID: <code>{target_user_id}</code>) uchun javob matnini yozing:",
        reply_markup=cancel_keyboard(),
    )
    await callback.answer()


@dp.message(AdminReplyState.waiting_reply)
async def admin_reply_send(message: Message, state: FSMContext):
    data = await state.get_data()
    target_user_id = data["target_user_id"]
    q_id = data["q_id"]
    await state.clear()

    try:
        await bot.send_message(
            target_user_id,
            f"✅ <b>Jonli operator javobi (#{q_id}-savol bo‘yicha):</b>\n\n{message.text}",
        )
        mark_question_answered(q_id, message.text, status="answered")
        await message.answer(
            f"✅ Javobingiz foydalanuvchiga (ID: <code>{target_user_id}</code>) yuborildi!",
            reply_markup=menu_by_user(message.from_user.id),
        )
    except Exception as e:
        await message.answer(f"❌ Xabar yuborilmadi: {e}", reply_markup=menu_by_user(message.from_user.id))


@dp.message(Command("reply"))
async def cmd_reply(message: Message):
    if message.from_user.id not in ADMIN_IDS:
        return

    parts = message.text.split(maxsplit=2)
    if len(parts) < 3:
        await message.answer("❗️ Format: <code>/reply USER_ID Javob matni</code>")
        return

    try:
        target_id = int(parts[1])
        reply_text = parts[2]
        await bot.send_message(target_id, f"✅ <b>Operator javobi:</b>\n\n{reply_text}")
        await message.answer(f"✅ Javob <code>{target_id}</code> raqamli foydalanuvchiga yuborildi.")
    except Exception as e:
        await message.answer(f"❌ Xatolik: {e}")


@dp.message(Command("stats"))
async def cmd_stats(message: Message):
    if message.from_user.id not in ADMIN_IDS:
        return

    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM users")
    total_users = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM users WHERE role = 'abituriyent'")
    abit_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM users WHERE role = 'talaba'")
    talaba_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM questions WHERE status = 'auto_answered'")
    auto_q = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM questions WHERE status = 'open'")
    open_q = cur.fetchone()[0]
    conn.close()

    await message.answer(
        "📊 <b>Bot statistikasi:</b>\n\n"
        f"👥 Jami foydalanuvchilar: <b>{total_users}</b>\n"
        f"🎓 Abituriyentlar: <b>{abit_count}</b>\n"
        f"🧑‍🎓 Talabalar: <b>{talaba_count}</b>\n"
        f"🤖 Avto-operator javob bergan: <b>{auto_q}</b>\n"
        f"❓ Jonli operator kutayotgan: <b>{open_q}</b>"
    )


# ==========================================
# 10. RENDER WEB SERVER VA ISHGA TUSHIRISH
# ==========================================
async def health_check(request):
    return web.Response(text="EduMaslahat_bot is running!")


async def start_web_server():
    app = web.Application()
    app.router.add_get("/", health_check)
    runner = web.AppRunner(app)
    await runner.setup()
    port = int(os.getenv("PORT", 10000))
    site = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()
    logging.info(f"Web server started on port {port}")


async def main():
    if BOT_TOKEN == "BU_YERGA_BOTFATHER_TOKENINI_QOYING" or ":" not in BOT_TOKEN:
        logging.error("XATOLIK: BOT_TOKEN kiritilmagan! Render Environment Variables bo'limiga BOT_TOKEN qo'shing.")
        return

    init_db()
    await start_web_server()
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
